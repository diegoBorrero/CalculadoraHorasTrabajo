import { Component, OnInit } from '@angular/core';
import {ReporteHorasDto} from '../../models/reporte-horas-dto';
import {AtencionClienteService} from '../../service/atencion-cliente.service';

@Component({
  selector: 'app-calcular-horas',
  templateUrl: './calcular-horas.component.html',
  styleUrls: ['./calcular-horas.component.css']
})
export class CalcularHorasComponent implements OnInit {

  reporte: ReporteHorasDto= new ReporteHorasDto();
  
  idtecnico: string="";
  semanaano: number;
  constructor(private atencionClienteService:AtencionClienteService) { }

  calcular():void{
    
    this.atencionClienteService.obtenerReporteHoras(this.idtecnico,this.semanaano)
      .subscribe( (res) => {
        this.reporte=res;
      });
  }
  ngOnInit(): void {
  }

}
