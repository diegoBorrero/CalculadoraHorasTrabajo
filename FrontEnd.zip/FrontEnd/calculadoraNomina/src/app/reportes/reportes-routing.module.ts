import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import {CalcularHorasComponent} from './calcular-horas/calcular-horas.component';

const routes: Routes = [{ path: '', component: CalcularHorasComponent}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ReportesRoutingModule { }
