import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule }   from '@angular/forms';

import { ReportesRoutingModule } from './reportes-routing.module';
import { CalcularHorasComponent } from './calcular-horas/calcular-horas.component';
import {AtencionClienteService} from '../service/atencion-cliente.service';
import { HttpClientJsonpModule } from '@angular/common/http';
import { HttpClientModule } from '@angular/common/http';

@NgModule({
  declarations: [CalcularHorasComponent],
  imports: [
    CommonModule,
    ReportesRoutingModule,
    HttpClientJsonpModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [AtencionClienteService]
})
export class ReportesModule { }
