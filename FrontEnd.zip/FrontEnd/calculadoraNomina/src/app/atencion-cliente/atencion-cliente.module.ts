import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule }   from '@angular/forms';

import { AtencionClienteRoutingModule } from './atencion-cliente-routing.module';
import { RegistrarServicioComponent } from './registrar-servicio/registrar-servicio.component';
import {AtencionClienteService} from '../service/atencion-cliente.service';
import { HttpClientJsonpModule } from '@angular/common/http';
import { HttpClientModule } from '@angular/common/http';


@NgModule({
  declarations: [RegistrarServicioComponent],
  imports: [
    CommonModule,
    AtencionClienteRoutingModule,
    FormsModule,
    HttpClientJsonpModule,
    HttpClientModule
  ],
  providers: [AtencionClienteService]
})
export class AtencionClienteModule { }
