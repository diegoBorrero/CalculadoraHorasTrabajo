import { Component, OnInit } from '@angular/core';
import {AtencionClienteDto} from '../../models/atencion-cliente-dto';
import {AtencionClienteService} from '../../service/atencion-cliente.service';

@Component({
  selector: 'app-registrar-servicio',
  templateUrl: './registrar-servicio.component.html',
  styleUrls: ['./registrar-servicio.component.css']
})
export class RegistrarServicioComponent implements OnInit {

  atencion : AtencionClienteDto = new AtencionClienteDto();
  constructor(private atencionClienteService: AtencionClienteService) { }

  ngOnInit(): void {
  }

  save(): void {

    this.atencionClienteService.registrarServicio(this.atencion)
      .subscribe( (res) => {
        if(res==true)
        {
          this.atencion.idtecnico="";
          this.atencion.idservicio="";
          this.atencion.fechainicio="";
          this.atencion.fechafin="";
          alert("Servicio Registrado");
        }
        else{
          alert("Servicio No Registrado");
        }
      });
    
  }

}
