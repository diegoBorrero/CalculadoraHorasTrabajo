export interface IReporteHorasDto{
    idTecnico: string;
    semanaAno: string;
    horasNormales: number;
    horasNocturnas: number;
    horasDominicales: number;
    horasNormalesExtras :number;
    horasNocturnasExtras:number;
    horasDominicalesExtras : number;
}

export class ReporteHorasDto implements IReporteHorasDto{
    idTecnico: string;
    semanaAno: string;
    horasNormales: number;
    horasNocturnas: number;
    horasDominicales: number;
    horasNormalesExtras :number;
    horasNocturnasExtras:number;
    horasDominicalesExtras : number;

    constructor(data?: IReporteHorasDto) {
        if (data) {
            for (var property in data) {
                if (data.hasOwnProperty(property))
                    (<any>this)[property] = (<any>data)[property];
            }
        }
    }

    init(data?: any) {
        if (data) {
            this.idTecnico = data["idTecnico"];
            this.semanaAno = data["semanaAno"];
            this.horasNormales  = data["horasNormales"];
            this.horasNocturnas = data["horasNocturnas"];
            this.horasDominicales = data["horasDominicales"];
            this.horasNormalesExtras = data["horasNormalesExtras"];
            this.horasNocturnasExtras = data["horasNocturnasExtras"];
            this.horasDominicalesExtras = data["horasDominicalesExtras"];
            }
    }

    static fromJS(data: any): ReporteHorasDto {
        let result = new ReporteHorasDto();
        result.init(data);
        return result;
    }

    toJSON(data?: any) {
        data = typeof data === 'object' ? data : {};
        
        this.idTecnico = data["idTecnico"];
            data["semanaAno"] = this.semanaAno;
            data["horasNormales"]= this.horasNormales;
            data["horasNocturnas"]= this.horasNocturnas;
            data["horasDominicales"] = this.horasDominicales;
            data["horasNormalesExtras"] = this.horasNormalesExtras;
            data["horasNocturnasExtras"]= this.horasNocturnasExtras;
            data["horasDominicalesExtras"]= this.horasDominicalesExtras;    
         

        return data; 
    }

    clone() {
        const json = this.toJSON();
        let result = new ReporteHorasDto();
        result.init(json);
        return result;
    }
}
