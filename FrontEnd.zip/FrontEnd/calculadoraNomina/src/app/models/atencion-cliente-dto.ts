export interface IAtencionClienteDto{
    idtecnico: string;
    idservicio: string;
    fechainicio: string;
    fechafin: string; 
}

export class AtencionClienteDto implements IAtencionClienteDto{
    idtecnico: string;
    idservicio: string;
    fechainicio: string;
    fechafin: string;

    constructor(data?: IAtencionClienteDto) {
        if (data) {
            for (var property in data) {
                if (data.hasOwnProperty(property))
                    (<any>this)[property] = (<any>data)[property];
            }
        }
    }

    init(data?: any) {
        if (data) {
            this.idtecnico = data["idtecnico"];
            this.idservicio = data["idservicio"];
            this.fechainicio  = data["fechainicio"];
            this.fechafin = data["fechafin"];
            }
    }

    static fromJS(data: any): AtencionClienteDto {
        let result = new AtencionClienteDto();
        result.init(data);
        return result;
    }

    toJSON(data?: any) {
        data = typeof data === 'object' ? data : {};
        
        data["idtecnico"] = this.idtecnico
        data["idservicio"] = this.idservicio   
        data["fechainicio"] = this.fechainicio    
        data["fechafin"] = this.fechafin    
         

        return data; 
    }

    clone() {
        const json = this.toJSON();
        let result = new AtencionClienteDto();
        result.init(json);
        return result;
    }
}
