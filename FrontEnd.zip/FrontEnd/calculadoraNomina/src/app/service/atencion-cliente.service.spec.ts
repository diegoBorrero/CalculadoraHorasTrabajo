import { TestBed } from '@angular/core/testing';

import { AtencionClienteService } from './atencion-cliente.service';

describe('AtencionClienteService', () => {
  let service: AtencionClienteService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(AtencionClienteService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
