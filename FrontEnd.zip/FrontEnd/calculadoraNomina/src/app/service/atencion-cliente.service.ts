/* Diego Borrero*/

// 07-02-2020

import { mergeMap as _observableMergeMap, catchError as _observableCatch } from 'rxjs/operators';
import { Observable, throwError as _observableThrow, of as _observableOf } from 'rxjs';
import { Injectable, Inject, Optional, InjectionToken } from '@angular/core';
import { HttpClient, HttpHeaders, HttpResponse, HttpResponseBase } from '@angular/common/http';
import {AtencionClienteDto} from '../models/atencion-cliente-dto';
import {ApiException} from '../models/api-exception';
import {ReporteHorasDto} from '../models/reporte-horas-dto';

@Injectable({
  providedIn: 'root'
})
export class AtencionClienteService {
  private http: HttpClient;
  private baseUrl: string="http://localhost:8080";
  protected jsonParseReviver: ((key: string, value: any) => any) | undefined = undefined;

  constructor(@Inject(HttpClient) http: HttpClient) {
      this.http = http;
      
  }
  /**
     * @param body (AtencionClienteDto) 
     * @return boolean
     */
  registrarServicio(body:AtencionClienteDto  | undefined): Observable<boolean>
  {
    let url_ =this.baseUrl+ "/api/atencion/guardar";
        url_ = url_.replace(/[?&]$/, "");

        const content_ = JSON.stringify(body);

        let options_ : any = {
          body: content_,
          observe: "response",
          responseType: "blob",
          headers: new HttpHeaders({
              "Content-Type": "application/json", 
              "Accept": "application/json"
          })
      };

      return this.http.request("post", url_, options_).pipe(_observableMergeMap((response_ : any) => {
        return this.processRegistrarServicio(response_);
    })).pipe(_observableCatch((response_: any) => {
        if (response_ instanceof HttpResponseBase) {
            try {
                return this.processRegistrarServicio(<any>response_);
            } catch (e) {
                return <Observable<boolean>><any>_observableThrow(e);
            }
        } else
            return <Observable<boolean>><any>_observableThrow(response_);
    }));

  }
  
  protected processRegistrarServicio(response: HttpResponseBase): Observable<boolean> {

    const status = response.status;
    const responseBlob = 
        response instanceof HttpResponse ? response.body : 
        (<any>response).error instanceof Blob ? (<any>response).error : undefined;

    let _headers: any = {}; if (response.headers) { for (let key of response.headers.keys()) { _headers[key] = response.headers.get(key); }};
    if (status === 200) {
        return blobToText(responseBlob).pipe(_observableMergeMap(_responseText => {
        let result200: any = null;
        let resultData200 = _responseText === "" ? null : JSON.parse(_responseText, this.jsonParseReviver);
        result200 = resultData200 !== undefined ? resultData200 : <any>null;
        return _observableOf(result200);
        }));
    } else if (status !== 200 && status !== 204) {
        return blobToText(responseBlob).pipe(_observableMergeMap(_responseText => {
        return throwException("An unexpected server error occurred.", status, _responseText, _headers);
        }));
    }
    return _observableOf<boolean>(<any>null);
}
/**
     * @param body (idtecnico: string,semanaAno: number) 
     * @return ReporteHorasDto
     */

obtenerReporteHoras(idtecnico: string,semanaAno: number): Observable<ReporteHorasDto>{

  let url_ =this.baseUrl+  "/api/atencion/";
        if (idtecnico === null)
            throw new Error("El parametro idtecnico no puede ser null.");
        else if (idtecnico !== undefined)
            url_ += encodeURIComponent("" + idtecnico) + "&"; 
        if (semanaAno === null)
            throw new Error("El parametro semanaAno no puede ser null.");
        else if (semanaAno !== undefined)
            url_ += encodeURIComponent("" + semanaAno) + "&";
        url_ = url_.replace(/[?&]$/, "");

        let options_ : any = {
            observe: "response",
            responseType: "blob",
            headers: new HttpHeaders({
                "Accept": "application/json"
            })
        };

        return this.http.request("get", url_, options_).pipe(_observableMergeMap((response_ : any) => {
            return this.processGet(response_);
        })).pipe(_observableCatch((response_: any) => {
            if (response_ instanceof HttpResponseBase) {
                try {
                    return this.processGet(<any>response_);
                } catch (e) {
                    return <Observable<ReporteHorasDto>><any>_observableThrow(e);
                }
            } else
                return <Observable<ReporteHorasDto>><any>_observableThrow(response_);
        }));

        
}

protected processGet(response: HttpResponseBase): Observable<ReporteHorasDto> {
  const status = response.status;
  const responseBlob = 
      response instanceof HttpResponse ? response.body : 
      (<any>response).error instanceof Blob ? (<any>response).error : undefined;

  let _headers: any = {}; if (response.headers) { for (let key of response.headers.keys()) { _headers[key] = response.headers.get(key); }};
  if (status === 200) {
      return blobToText(responseBlob).pipe(_observableMergeMap(_responseText => {
      let result200: any = null;
      let resultData200 = _responseText === "" ? null : JSON.parse(_responseText, this.jsonParseReviver);
      result200 = ReporteHorasDto.fromJS(resultData200);
      return _observableOf(result200);
      }));
  } else if (status !== 200 && status !== 204) {
      return blobToText(responseBlob).pipe(_observableMergeMap(_responseText => {
      return throwException("An unexpected server error occurred.", status, _responseText, _headers);
      }));
  }
  return _observableOf<ReporteHorasDto>(<any>null);
}



}

function throwException(message: string, status: number, response: string, headers: { [key: string]: any; }, result?: any): Observable<any> {
  if (result !== null && result !== undefined)
      return _observableThrow(result);
  else
      return _observableThrow(new ApiException(message, status, response, headers, null));
}

function blobToText(blob: any): Observable<string> {
  return new Observable<string>((observer: any) => {
      if (!blob) {
          observer.next("");
          observer.complete();
      } else {
          let reader = new FileReader(); 
          reader.onload = event => { 
              observer.next((<any>event.target).result);
              observer.complete();
          };
          reader.readAsText(blob); 
      }
  });
}
